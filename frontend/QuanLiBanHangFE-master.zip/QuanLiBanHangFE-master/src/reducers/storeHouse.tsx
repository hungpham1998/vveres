const menu = "xxx";
export default menu;