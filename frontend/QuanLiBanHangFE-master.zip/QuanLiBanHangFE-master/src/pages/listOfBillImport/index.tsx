import React from "react";

class ListOfBillImportComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                ListOfBillImportComponent
            </div>
        )
    }
}

export default ListOfBillImportComponent;