import React from "react";

class HistoryOfChangeStoreHouseComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                HistoryOfChangeStoreHouseComponent
            </div>
        )
    }
}

export default HistoryOfChangeStoreHouseComponent;