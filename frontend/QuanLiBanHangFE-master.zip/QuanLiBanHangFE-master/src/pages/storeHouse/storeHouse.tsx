import React from "react";

class StoreHouseComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {}
    }
    render() {
        return (
            <div> 
                afksdjklfjasdklfj
            </div>
        )
    }
}

export default StoreHouseComponent;