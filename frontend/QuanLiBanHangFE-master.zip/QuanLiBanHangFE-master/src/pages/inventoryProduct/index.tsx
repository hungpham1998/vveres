import React from "react";

class InventoryProductComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                InventoryProductComponent
            </div>
        )
    }
}

export default InventoryProductComponent;