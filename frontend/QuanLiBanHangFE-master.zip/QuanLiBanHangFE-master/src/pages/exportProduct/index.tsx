import React from "react";

class ExportProductComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                ExportProductComponent
            </div>
        )
    }
}

export default ExportProductComponent;