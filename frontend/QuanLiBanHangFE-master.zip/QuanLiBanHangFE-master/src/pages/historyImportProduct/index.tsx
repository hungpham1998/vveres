import React from "react";

class HistoryImportProductComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                HistoryImportProductComponent
            </div>
        )
    }
}

export default HistoryImportProductComponent;