import React from "react";
import StoreHouseComponent from "../storeHouse/storeHouse";

class StaffmentComponent extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
    }

    render() {
        return (
            <div>
                staffment
            </div>
        )
    }
}

export default StaffmentComponent;