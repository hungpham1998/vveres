import React from "react";

class ImportProductComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                ImportProductComponent
            </div>
        )
    }
}

export default ImportProductComponent;