import React from "react";

class SupplierComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                supplier
            </div>
        )
    }
}

export default SupplierComponent;