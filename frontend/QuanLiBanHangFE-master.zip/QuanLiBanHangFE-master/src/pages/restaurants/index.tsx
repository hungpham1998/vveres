import React from "react";

class RestaurantComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                RestaurantComponent
            </div>
        )
    }
}

export default RestaurantComponent;