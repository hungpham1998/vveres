import React from "react";

class ListOfBillExportComponent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

    }

    render() {
        return(
            <div>
                ListOfBillExportComponent
            </div>
        )
    }
}

export default ListOfBillExportComponent;